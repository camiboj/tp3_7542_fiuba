#include "client_processor.h"

Processor::Processor(Protocol& _protocol) : protocol(_protocol) {}
Processor::~Processor() {}
